//
//  ViewController.swift
//  Sample Project
//
//  Created by kristhian deoliveira on 12/16/18.
//  Copyright © 2018 kristhian deoliveira. All rights reserved.
//

import UIKit
import Lottie
import AVFoundation

class ViewController: UIViewController {
    @IBOutlet weak var animateSwipe: UIView!
    var Song: AVAudioPlayer?
    var Song2: AVAudioPlayer?
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var inputURL: UITextField!
    @IBOutlet weak var FindIURL_BTN: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        animateSwipe.backgroundColor = UIColor.white
        view.backgroundColor = UIColor.green
        //Play Song
        let path = Bundle.main.path(forResource: "Song.mp3", ofType:nil)!
        let url = URL(fileURLWithPath: path)
        
        do {
            Song = try AVAudioPlayer(contentsOf: url)
            Song?.play()
        } catch {
            // couldn't load file :(
        }
    }
    @IBAction func Find_URL(_ sender: Any) {
        view.backgroundColor = UIColor.red
        image.imageFromUrl(urlString: inputURL.text!)
        let animationView = LOTAnimationView(name: "christmas_loader")
        self.view.addSubview(animationView)
        animationView.play{ (finished) in
            self.view.backgroundColor = UIColor.blue
            self.FindIURL_BTN.backgroundColor = UIColor.red
            self.inputURL.backgroundColor = UIColor.green
            self.FindIURL_BTN.tintColor = UIColor.white
            //Play Song
            let path = Bundle.main.path(forResource: "HOHOHO.mp3", ofType:nil)!
            let url = URL(fileURLWithPath: path)
            
            do {
                self.Song2 = try AVAudioPlayer(contentsOf: url)
                self.Song2?.play()
            } catch {
                // couldn't load file :(
            }

        }
          self.Song?.stop()
        
        let animationView2 = LOTAnimationView(name: "christmas_tree_with_gifts")
        self.FindIURL_BTN.addSubview(animationView2)
        animationView2.play{ (finished) in
            self.view.backgroundColor = UIColor.blue
        }
    }
}

